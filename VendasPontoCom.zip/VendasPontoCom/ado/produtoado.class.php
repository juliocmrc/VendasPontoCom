<?php
/**
 * Implementa os métodos de persistência para a tabela Produtos.
 *
 * @author Elymar Pereira Cabral <elymar.cabral@ifg.edu.br>
 */
require_once 'adoabstract.class.php';
require_once '../modelo/modelabstract.class.php';
require_once '../modelo/produtomodel.class.php';

class ProdutoADO extends ADOAbstract {
    private $produtoModel = null;

    function __construct ($produtoModel = NULL) {
        parent::__construct ("Produtos");

        if (is_null ($produtoModel)) {
            $this->produtoModel = new ProdutoModel();
        } else {
            $this->produtoModel = $produtoModel;
        }
    }

    /*
     * Comentários em relação aos métodos de insersão, alteração e exclusão:
     * Esses três métodos foram implementados em duas versões por questão 
     * didática. Uma versão está com todo código explícito para que os discentes
     * visualizem todo o processo da escrita da instrução até a sua execução 
     * usando a conexão com o banco de dados.
     * A outra versão está escrita reaproveitando métodos genéricos que diminuem 
     * a escrita por parte do programador e padroniza o código.
     * 
     * Dessa forma espera-se deixar claro aos discentes como o uso da POO com 
     * vistas ao reaproveitamento de código leva a uma programação mais ágil e
     * acertiva.
     */

    /*
     * Esta é a versão 1 da insersão e implementa toda a codificação sem 
     * reaproveitamento de código.
     */
//    public function insereObjeto () {
//        //monta a string da instrução insert.
//        $insert = "insert into Produtos  "
//                . "(`prodId`, "
//                . "`prodNome`, "
//                . "`prodDescricao`, "
//                . "`prodValor`, "
//                . "`prodQtdeEmEstoque`)  "
//                . "values "
//                . "((?), (?), (?), (?), (?) ";
//        $arrayDeValores = array (
//            "prodId"            => $this->produtoModel->getProdId (),
//            "prodNome"          => $this->produtoModel->getProdNome (),
//            "prodDescricao"     => $this->produtoModel->getProdDescricao (),
//            "prodValor"         => $this->produtoModel->getProdValor (),
//            "prodQtdeEmEstoque" => $this->produtoModel->getProdQtdeEmEstoque ()
//        );
//        
//        $conexao = $this->getConexao();
//        try {
//            $preparou = $conexao->prepare ($insert);
//            if ($preparou) {
//                $pdoStatment = $preparou;
//            } else {
//                $this->geraLogDeErro ($insert, "PREPARE : " . $conexao->errorInfo ());
//                return false;
//            }
//        } catch (Exception $e) {
//            $this->geraLogDeErro ($insert, $e->getMessage ());
//            return false;
//        }
//
//        try {
//            $executou = $pdoStatment->execute (array_values ($arrayDeValores));
//            if ($executou) {
//                $this->geraLogDeExecucao ($insert, 'insereObjeto');
//                return true;
//            } else {
//                $this->geraLogDeErro ($insert, $this->getBdError ());
//                return false;
//            }
//        } catch (Exception $e) {
//            $this->geraLogDeErro ($insert, "EXECUTE : " . $e->getMessage ());
//            return false;
//        }
//    }

    /*
     * Esta é a versão 2 da insersão e utiliza de métodos da classe mãe.
     */
    public function insereObjeto () {
        $colunasValores = array (
            "prodId"            => $this->produtoModel->getProdId (),
            "prodNome"          => $this->produtoModel->getProdNome (),
            "prodDescricao"     => $this->produtoModel->getProdDescricao (),
            "prodValor"         => $this->produtoModel->getProdValor (),
            "prodQtdeEmEstoque" => $this->produtoModel->getProdQtdeEmEstoque ()
        );

        $insert = $this->montaStringDoInsert ($colunasValores);

        return $this->executaQuery ($insert, $colunasValores);
    }

    /*
     * Esta é a versão 1 da alteração e implementa toda a codificação sem 
     * reaproveitamento de código.
     */
//    public function alteraObjeto () {
//        //monta a string da instrução update.
//        $update         = "update Produtos "
//                . "set `prodNome` = (?), "
//                . "`prodDescricao` = (?), "
//                . "`prodValor` = (?), "
//                . "`prodQtdeEmEstoque` = (?) "
//                . "where `prodId` = ? ";
//        $arrayDeValores = array (
//            "prodNome"          => $this->produtoModel->getProdNome (),
//            "prodDescricao"     => $this->produtoModel->getProdDescricao (),
//            "prodValor"         => $this->produtoModel->getProdValor (),
//            "prodQtdeEmEstoque" => $this->produtoModel->getProdQtdeEmEstoque (),
//            "prodId"            => $this->produtoModel->getProdId ()
//        );
//
//        $conexao = $this->getConexao ();
//        try {
//            $preparou = $conexao->prepare ($update);
//            if ($preparou) {
//                $pdoStatment = $preparou;
//            } else {
//                $this->geraLogDeErro ($update, "PREPARE : " . $conexao->errorInfo ());
//                return false;
//            }
//        } catch (Exception $e) {
//            $this->geraLogDeErro ($update, $e->getMessage ());
//            return false;
//        }
//
//        try {
//            $executou = $pdoStatment->execute (array_values ($arrayDeValores));
//            if ($executou) {
//                $this->geraLogDeExecucao ($update, 'alteraObjeto');
//                return true;
//            } else {
//                $this->geraLogDeErro ($update, $this->getBdError ());
//                return false;
//            }
//        } catch (Exception $e) {
//            $this->geraLogDeErro ($update, "EXECUTE : " . $e->getMessage ());
//            return false;
//        }
//    }

    /*
     * Esta é a versão 2 da alteração e utiliza de métodos da classe mãe.
     */
    public function alteraObjeto () {
        //monta o array dos dados para alteração.
        $colunasParaAlteracao = array (
            "prodNome"          => $this->produtoModel->getProdNome (),
            "prodDescricao"     => $this->produtoModel->getProdDescricao (),
            "prodValor"         => $this->produtoModel->getProdValor (),
            "prodQtdeEmEstoque" => $this->produtoModel->getProdQtdeEmEstoque ()
        );
        //monta a chave para a alteração.
        $colunasChave         = array (
            "prodId" => $this->produtoModel->getProdId ()
        );
        $instrucao            = $this->montaStringDoUpdate ($colunasParaAlteracao, $colunasChave);

        return $this->executaQuery ($instrucao, array_merge ($colunasParaAlteracao, $colunasChave));
    }

    /*
     * Esta é a versão 1 da exclusão e implementa toda a codificação sem 
     * reaproveitamento de código.
     */
//    public function excluiObjeto () {
//        //monta a string da instrução delete.
//        $delete         = "delete from Produtos where `prodId` = ? ";
//        $arrayDeValores = array (
//            "prodId" => $this->produtoModel->getProdId ()
//        );
//
//        $conexao = $this->getConexao ();
//        try {
//            $preparou = $conexao->prepare ($delete);
//            if ($preparou) {
//                $pdoStatment = $preparou;
//            } else {
//                $this->geraLogDeErro ($delete, "PREPARE : " . $conexao->errorInfo ());
//                return false;
//            }
//        } catch (Exception $e) {
//            $this->geraLogDeErro ($delete, $e->getMessage ());
//            return false;
//        }
//
//        try {
//            $executou = $pdoStatment->execute (array_values ($arrayDeValores));
//            if ($executou) {
//                $this->geraLogDeExecucao ($delete, 'alteraObjeto');
//                return true;
//            } else {
//                $this->geraLogDeErro ($delete, $this->getBdError ());
//                return false;
//            }
//        } catch (Exception $e) {
//            $this->geraLogDeErro ($delete, "EXECUTE : " . $e->getMessage ());
//            return false;
//        }
//    }

    /*
     * Esta é a versão 2 da exclusão e utiliza de métodos da classe mãe.
     */
    public function excluiObjeto () {
        //monta a chave para a alteração.
        $colunasChave         = array (
            "prodId" => $this->produtoModel->getProdId ()
        );
        $instrucao            = $this->montaStringDoDeleteParametrizada ($colunasChave);

        return $this->executaQuery ($instrucao, $colunasChave);
    }

    /**
     * Monta o objeto ProdutoModel a partir do dados lidos.
     * Este método sobrescreve o método da AdoAbstract para completar a 
     * funcionalidade.
     * 
     * @param type $produto Objeto lido no padão FETCH_OBJ
     * @return \ProdutoModel Objeto model
     */
    public function montaObjeto ($produto) {
        return new ProdutoModel ($produto->prodId, $produto->prodNome, $produto->prodDescricao, $produto->prodValor, $produto->prodQtdeEmEstoque);
    }

    public function buscaProdutosOrdenadosPorNome () {
        return $this->buscaArrayObjeto (null, 1, "ORDER BY prodNome");
    }

    public function buscaProduto ($prodId) {
        return $this->buscaObjeto (array ($prodId), "prodId = ?");
    }

    function getProdutoModel () {
        return $this->produtoModel;
    }

    function setProdutoModel ($produtoModel): void {
        $this->produtoModel = $produtoModel;
    }

}