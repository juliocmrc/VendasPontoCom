<?php
require_once '../controle/clientecontroller.class.php';

$clienteController = new ClienteController();

unset ($clienteController);

?>