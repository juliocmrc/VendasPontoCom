<?php
require_once '../controle/alteraclientecontroller.class.php';

$clienteController = new AlteraClienteController();

unset ($clienteController);

?>