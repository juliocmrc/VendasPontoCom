<?php
require_once '../controle/produtocontroller.class.php';

$produtoController = new ProdutoController();

unset ($produtoController);
?>