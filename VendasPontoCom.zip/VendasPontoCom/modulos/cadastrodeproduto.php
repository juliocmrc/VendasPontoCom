<?php
require_once '../visao/produtoview.class.php';
require_once '../modelo/produtomodel.class.php';
require_once '../ado/produtoado.class.php';

$produtoView = new ProdutoView();

$acao = $produtoView->getAcao ();

switch ($acao) {
    case "nova" :
        //Se for uma nova tela não precisa fazer nada!
        break;

    case "inserir":
        $produtoModel = $produtoView->recebeDadosDaInterface ();
        //Independentemente do que for recebido da view, na insersão o id do
        //produto deve ser sempre null.
        $produtoModel->setProdId (null);

        $dadosOk = $produtoModel->checaAtributos ();
        if ($dadosOk) {
            //Se checagem ok, continua para a insersão.
            $produtoADO = new ProdutoADO ($produtoModel);
            $incluiu    = $produtoADO->insereObjeto ();
            if ($incluiu) {
                $produtoModel = new ProdutoModel();
                $produtoView->adicionaMensagem ("Produto inserido com sucesso!");
            } else {
                $produtoView->adicionaMensagem ("Ocorreu um problema na insersão do produto, informe ao responsável pelo sistema!");
            }
        } else {
            //se retornar com erro repassa as mensagens para a interface.
            $produtoView->adicionaMensagens ($produtoModel->getMensagens ());
        }

        $produtoView->setProdutoModel ($produtoModel);

        break;

    case "consultar":
        $prodId = $produtoView->recebeChaveDaConsulta ();

        $produtoADO   = new ProdutoADO();
        $buscou       = $produtoModel = $produtoADO->buscaProduto ($prodId);
        if ($buscou) {
            $produtoView->setProdutoModel ($produtoModel);
        } else {
            //se retornar com erro repassa as mensagens para a interface.
            $produtoView->adicionaMensagem("Não foi possível encontrar o produto! Tente novamente ou informe o problema ao responsável pelo sistema.");
        }

        break;

    case "alterar":
        $produtoModel = $produtoView->recebeDadosDaInterface ();

        $dadosOk = $produtoModel->checaAtributos ();
        if ($dadosOk) {
            //Se checagem ok, continua para a alteração.
            $produtoADO = new ProdutoADO ($produtoModel);
            $alterou    = $produtoADO->alteraObjeto ();
            if ($alterou) {
                $produtoModel = new ProdutoModel();
                $produtoView->adicionaMensagem ("Produto alterado com sucesso!");
            } else {
                $produtoView->adicionaMensagem ("Ocorreu um problema na alteração do produto, informe ao responsável pelo sistema!");
            }
        } else {
            //se retornar com erro repassa as mensagens para a interface.
            $produtoView->adicionaMensagens ($produtoModel->getMensagens ());
        }

        $produtoView->setProdutoModel ($produtoModel);

        break;

    case "excluir":
        $produtoModel = $produtoView->recebeDadosDaInterface ();

        $produtoADO = new ProdutoADO ($produtoModel);
        $excluiu    = $produtoADO->excluiObjeto ();
        if ($excluiu) {
            $produtoModel = new ProdutoModel();
            $produtoView->adicionaMensagem ("Produto excluído com sucesso!");
        } else {
            $produtoView->adicionaMensagem ("Ocorreu um problema na exclusão do produto, informe ao responsável pelo sistema!");
        }

        $produtoView->setProdutoModel ($produtoModel);

        break;
        
    case "limpar":
        $produtoModel = new ProdutoModel();
        
        $produtoView->setProdutoModel($produtoModel);
        
        break;
}

$produtoView->geraInterface ();
?>