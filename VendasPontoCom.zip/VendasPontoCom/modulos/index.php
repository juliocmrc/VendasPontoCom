<?php
header("Location: vpc.php");
?>

