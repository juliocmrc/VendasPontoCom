<?php
require_once '../visao/minhaview.class.php';

$minhaView = new MinhaView();

$minhaView->geraInterface();
?>

