<?php
require_once '../controle/logincontroller.class.php';

$loginClienteController = new LoginController();

unset ($loginClienteController);

?>