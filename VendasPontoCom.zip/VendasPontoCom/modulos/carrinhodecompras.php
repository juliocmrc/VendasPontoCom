<?php
require_once '../controle/carrinhodecomprascontroller.class.php';

$carrinhoDeComprasController = new CarrinhoDeComprasController();

unset ($carrinhoDeComprasController);
?>