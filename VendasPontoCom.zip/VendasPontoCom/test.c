#include <stdio.h>
#include <stdlib.h>


int main (int argc, char *argv[]) // 
{ int linha, coluna;
  int i;
  int operacao; //operacao//
  int matrizA [3] [2] = { {1, 2}, {0, 3}, {4, 1}}; // matrizA//
  int matrizB [2] [3] = { {2, 1, 0}, {4, 0, 1}}; //matrizB//
  int matrizC [3] [3]; //matrizC//
  int M1L = 3, M1C = 3, M2L= 3, M2C= 3; //variaveis que receberao a multiplicacao
    
    for(linha = 0; linha < M1L; linha++) //percorrendo as matrizes//
        for(coluna = 0; coluna < M2C; coluna++){ 
            operacao = 0;
            for(i = 0; i < M1L; i++)
        operacao += matrizA[linha][i]*matrizB[i][coluna]; // atribuindo a operacao a variavel operacao
        matrizC [linha] [coluna] = operacao; //fazendo a atribuicao a operacao
        }
  for(linha = 0; linha <M1L; linha++){ //laco for para percorrer e guardar a multiplicacao
    for(coluna = 0; coluna < M2C; coluna++)
        printf("%d", matrizC[linha][coluna]);//imprimindo a matriz 
        printf("\n");
       }
       
       system("PAUSE");
       return 0;
}