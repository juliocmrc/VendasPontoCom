Este projeto é relativo ao trabalho final da disciplina de Desenvolvimento de Aplicaçõe para Web I. Dentre as funções realizadas, temos: cadastro de cliente e produto, login e logout 
de cliente, alteração dos dados do cliente, adição, remoção e o esvaziar do carrinho de compras. O projeto possui conexão com o banco de dados para armazenamento dos clientes, 
produtos e do carrinho de compras com os produtos relacionados a cada cliente. A tela de cadastro de produtos não é acessível para o cliente, pois é uma função exclusiva do 
administrador. Entretanto, como não foi possível implementar as partes referentes à interface do administrador, o acesso à página de cadastro de produtos é feita apenas digitando a 
URL que leva ao seu arquivo, que é "localhost/VendasPontoCom/modulos/cadastrodeproduto.php".

Trabalho feito por: Jean Carlos Lúcio Vieira e Júlio César Mendes Rodrigues de Carvalho.