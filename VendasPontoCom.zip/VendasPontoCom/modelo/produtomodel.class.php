<?php
require_once 'modelabstract.class.php';

class ProdutoModel extends ModelAbstract {
    private $prodId            = null;
    private $prodNome          = null;
    private $prodDescricao     = null;
    private $prodValor         = null;
    private $prodQtdeEmEstoque = null;

    function __construct ($prodId = null, $prodNome = null,
                          $prodDescricao = null, $prodValor = null,
                          $prodQtdeEmEstoque = null) {
        parent::__construct ();

        $this->prodId            = $prodId;
        $this->prodNome          = $prodNome;
        $this->prodDescricao     = $prodDescricao;
        $this->prodValor         = $prodValor;
        $this->prodQtdeEmEstoque = $prodQtdeEmEstoque;
    }

    public function checaAtributos () {
        $atributosOk = true;

        //prodId
        //Apesar de ser obrigatório não é necessário checar pq é 
        //autoincrementável e não se deixa o usuário informá-lo.

        //prodNome
        //É obrigatório e com no máximo 45 caracteres.
        if (is_null ($this->prodNome) || trim ($this->prodNome) == '') {
            $atributosOk = false;
            $this->adicionaMensagem ("Deve-se informar o nome!");
        } else {
            //Se informado deve ser conter no máximo 45 caracteres.
            if (strlen ($this->prodNome) > 45) {
                $atributosOk = false;
                $this->adicionaMensagem ("Informe no máximo 45 caracteres pro nome!");
            }
        }

        //prodDescrição
        //É obrigatório e com máximo de 500 caracteres.
        if (is_null ($this->prodDescricao) || trim ($this->prodDescricao) == '') {
            $atributosOk = false;
            $this->adicionaMensagem ("Deve-se informar a descrição!");
        } else {
            //Se informado deve ser conter no máximo 500 caracteres.
            if (strlen ($this->prodDescricao) > 500) {
                $atributosOk = false;
                $this->adicionaMensagem ("Informe no máximo 500 caracteres para a descrição!");
            }
        }

        //prodValor
        //É obrigatório e numérico com casas decimais.
        if (is_null ($this->prodValor) || trim ($this->prodValor) == '') {
            $atributosOk = false;
            $this->adicionaMensagem ("Deve-se informar o valor!");
        } else {
            //Se informado deve ser conter no máximo 500 caracteres.
            if (is_double($this->prodValor)) {
                
            }else{
                $atributosOk = false;
                $this->adicionaMensagem ("O valor deve ser do tipo double!");
            }
        }

        //prodQtdeEmEstoque
        //Obrigatório, inteiro.

        if (is_null ($this->prodQtdeEmEstoque) || trim ($this->prodQtdeEmEstoque) == '') {
            $atributosOk = false;
            $this->adicionaMensagem ("Deve-se informar a quantidade em estoque!");
        } else {
            //Se informado deve ser inteiro.
            if (is_int($this->prodQtdeEmEstoque)) {
                
            }else{
                $atributosOk = false;
                $this->adicionaMensagem ("A quantidade em estoque deve ser do tipo inteiro!");
            }
        }


        return $atributosOk;
    }

    function getProdId () {
        return $this->prodId;
    }

    function getProdNome () {
        return $this->prodNome;
    }

    function getProdDescricao () {
        return $this->prodDescricao;
    }

    function getProdValor () {
        return $this->prodValor;
    }

    function getProdQtdeEmEstoque () {
        return $this->prodQtdeEmEstoque;
    }

    function setProdId ($prodId): void {
        $this->prodId = $prodId;
    }

    function setProdNome ($prodNome): void {
        $this->prodNome = $prodNome;
    }

    function setProdDescricao ($prodDescricao): void {
        $this->prodDescricao = $prodDescricao;
    }

    function setProdValor ($prodValor): void {
        $this->prodValor = $prodValor;
    }

    function setProdQtdeEmEstoque ($prodQtdeEmEstoque): void {
        $this->prodQtdeEmEstoque = $prodQtdeEmEstoque;
    }

}
?>